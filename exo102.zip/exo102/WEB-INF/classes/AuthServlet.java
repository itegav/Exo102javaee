import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;
import java.util.Objects;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/auth")
public class AuthServlet extends HttpServlet {

	// TODO : only handle POST request for authentication
	// @Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
	throws ServletException, IOException {
		resp.setContentType("text/html");
		// TODO : get login / password from request parameters
		String login = req.getParameter("login");
		String password = req.getParameter("password");
		String login_admin = "admin@greta.fr";
		String password_admin = "hello";
		if ( login == null || password == null ) throw new ServletException("error : no login/password");
		boolean succeed = login_admin.equals(login) && password_admin.equals(password);
		
		// TODO : if auth is OK,
		PrintWriter out = resp.getWriter();
		if (succeed){
			RequestDispatcher rd = req.getRequestDispatcher("welcome.jsp");
			req.setAttribute("login", login );
			req.setAttribute("password", password);
			rd.forward(req, resp);
		}
		else {
			// TODO : if auth KO
			// set an "errorMessage" in request attribute
			// forward to auth.jsp with request dispatche
			req.setAttribute("login", "error" );
			req.setAttribute("password", "error");
			RequestDispatcher rd = req.getRequestDispatcher("auth.jsp");
			rd.forward(req, resp);

		}



	}
	
	// TODO : allow to disconnect with a GET to /auth with any parameter "logout" value
	// @Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
	throws ServletException, IOException {
	  // TODO : check for "logout" parameter
		String logout = req.getParameter("logout");
		if (Objects.equals(logout, "logout")) {
			PrintWriter out = resp.getWriter();
			req.setAttribute("deco","deconnexion");
			RequestDispatcher rd = req.getRequestDispatcher("auth.jsp");
			rd.forward(req, resp);
		}
		else {
			//error 500
		}
	  //   if so : disconnect and show auth.jsp
	  //   if not : Error 500
	}

}